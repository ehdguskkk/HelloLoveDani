'use client'
import { useEffect, useState } from "react";
import { db } from "@/firebase";
import { collection, getDocs } from "firebase/firestore";
import Link from "next/link";

export default function ProductsPage() {
  const [products, setProducts] = useState<any[]>([]);

  useEffect(() => {
    async function fetchProducts() {
      const snapshot = await getDocs(collection(db, "products"));
      setProducts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }
    fetchProducts();
  }, []);

  if (products.length === 0) return <div className="p-10">등록된 상품이 없습니다.</div>;

  return (
    <div className="p-10 grid grid-cols-2 md:grid-cols-3 gap-8">
      {products.map(product => (
        <Link key={product.id} href={`/products/${product.id}`} className="border rounded p-4 shadow hover:shadow-lg">
          <img src={product.image} alt={product.name} className="w-full h-48 object-cover rounded mb-2" />
          <div className="font-bold text-lg">{product.name}</div>
          <div className="text-gray-600 mb-1">{product.description}</div>
          <div className="font-semibold">${product.price}</div>
        </Link>
      ))}
    </div>
  );
}