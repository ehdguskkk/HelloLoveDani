'use client';
import { useEffect, useState } from 'react';
import { auth } from '@/firebase';
import { signInWithPopup, GoogleAuthProvider, signOut, onAuthStateChanged } from 'firebase/auth';

const ADMIN_EMAIL = "sae4762@gmail.com"; // 관리자 이메일(여러 개면 배열로 확장)

export default function AdminPage() {
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    // 로그인 상태 감지
    const unsub = onAuthStateChanged(auth, (u) => setUser(u));
    return () => unsub();
  }, []);

  const handleGoogleLogin = async () => {
    await signInWithPopup(auth, new GoogleAuthProvider());
  };
  const handleLogout = async () => {
    await signOut(auth);
  };

  // 관리자 이메일만 접근 가능!
  if (!user)
    return (
      <div className="h-screen flex items-center justify-center">
        <button className="bg-yellow-500 px-8 py-3 rounded text-lg text-white" onClick={handleGoogleLogin}>
          구글 로그인으로 관리자 진입
        </button>
      </div>
    );
  if (user.email !== ADMIN_EMAIL)
    return (
      <div className="h-screen flex items-center justify-center flex-col gap-4">
        <span>관리자 권한이 없습니다.<br />현재 로그인: {user.email}</span>
        <button className="bg-gray-300 px-6 py-2 rounded" onClick={handleLogout}>로그아웃</button>
      </div>
    );

  // --- 여기 아래에 관리자 전용 UI(상품 관리 등) 붙이면 됨! ---
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">어드민 상품 관리 페이지</h1>
      <button className="bg-red-400 px-4 py-1 rounded text-white" onClick={handleLogout}>로그아웃</button>
      {/* 실제 관리자 기능 컴포넌트(상품 추가/수정/삭제) 여기에! */}
    </div>
  );
}