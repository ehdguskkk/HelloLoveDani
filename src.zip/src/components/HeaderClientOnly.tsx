'use client';
import Header from './Header';

export default function HeaderClientOnly() {
  return <Header />;
}